import logging
import re
from odoo import models, fields, api
import base64
from werkzeug.utils import escape

_logger = logging.getLogger(__name__)


class ProjectTask(models.Model):
    _inherit = 'project.task'

    xml_file = fields.Binary(string="Diagram XML", attachment=False)
    xml_file_name = fields.Char(string="XML File Name")
    svg_image = fields.Binary(string="Diagram SVG", attachment=False)
    png_preview = fields.Binary(string="PNG Preview", attachment=False)

    @api.model
    def save_file(self, task_id=None, content=None, image_1920=None, image_svg=None):
        task = self.browse(task_id)
        if not task:
            return False
        xml_filename = f"{escape(task.name or 'diagram')}.xml"
        task.write({
            'xml_file': content,
            'xml_file_name': xml_filename,
            'svg_image': image_svg,
            'png_preview': image_1920,
        })
        return True

    def download_svg(self):
        self.ensure_one()
        if self.image_svg:
            return {
                'type': 'ir.actions.act_url',
                'url': f'/web/content/{self.svg_image}?download=true',
                'target': 'self',
            }
        return False

    @api.model
    def get_xml_data(self, task_id):
        task = self.browse(task_id)
        if task and task.xml_file:
            try:
                xml_bytes = base64.b64decode(task.xml_file)
                xml_str = xml_bytes.decode('utf-8')
                return {
                    'xml': xml_str,
                    'filename': task.xml_file_name or 'diagram.bpmn.xml',
                }
            except Exception:
                return {'xml': False, 'filename': False}
        return {'xml': False, 'filename': False}

    def download_xml(self):
        self.ensure_one()
        if self.xml_file:
            return {
                'type': 'ir.actions.act_url',
                'url': f"/web/content/project.task/{self.id}/xml_file/{self.xml_file_name}?download=true",
                'target': 'self',
            }
        return False

    def action_open_bpmn_editor(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.client',
            'tag': 'bpmn_diagram_tags',
            'name': 'Task BPMN Editor',
            'target': 'self',
            'context': {
                'task_id': self.id,
                'task_name': self.name,
                'active_model': self._name,
                'active_id': self.id,
            },
        }

