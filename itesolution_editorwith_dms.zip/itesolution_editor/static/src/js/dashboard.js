/** @odoo-module **/
import { Component, onMounted, useRef } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";

export class BpmnDiagram extends Component {
    setup() {
        this.diagramAreaRef = useRef("diagramArea");
        this.propertiesPanelRef = useRef("propertiesPanel");
        this.uploadInputFabRef = useRef("uploadInputFab"); // ✅ new ref
        this.rpc = rpc;
        this.notification = useService("notification");
        const dmsFileId = this.props.action.context?.dms_file_id;
        const fileName = this.props.action.context?.file_name;
        this.dmsFileId = dmsFileId;
        this.fileName  = fileName

        onMounted(() => this.initBpmnModeler());
    }

    async initBpmnModeler() {
        const diagramArea = this.diagramAreaRef.el;
        const propertiesPanel = this.propertiesPanelRef.el;

        if (!diagramArea || !propertiesPanel) {
            console.error("Diagram or properties panel container not found.");
            return;
        }

        this.bpmnModeler = new window.BpmnJS({
            container: diagramArea,
            keyboard: { bindTo: window },
            propertiesPanel: { parent: propertiesPanel },
        });

        const taskId = this.props.action.context?.task_id;

        if (taskId) {
            try {
                const response = await this.rpc("/web/dataset/call_kw", {
                    model: "project.task",
                    method: "get_xml_data",
                    args: [taskId],
                    kwargs: {},
                });

                const xmlStr = response.xml;
                const fileName = response.filename;

                if (xmlStr) {
                    await this.bpmnModeler.importXML(xmlStr);
                    this.fileName = fileName;
                    console.log("Loaded XML from server");
                } else {
                    this.createNewDiagram();
                }
            } catch (e) {
                console.error("Failed to load XML", e);
                this.createNewDiagram();
            }
        } else {
            this.createNewDiagram();
        }
    }

    async createNewDiagram() {
        const xml = `<?xml version="1.0" encoding="UTF-8"?>
                <bpmn:definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL"
                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                  xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI"
                  xmlns:dc="http://www.omg.org/spec/DD/20100524/DC"
                  xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
                  id="Definitions_1"
                  targetNamespace="http://bpmn.io/schema/bpmn">
                  <bpmn:process id="Process_1" isExecutable="false">
                    <bpmn:startEvent id="StartEvent_1" name="Start" />
                  </bpmn:process>
                  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
                    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
                      <bpmndi:BPMNShape id="BPMNShape_StartEvent_1" bpmnElement="StartEvent_1">
                        <dc:Bounds x="150" y="100" width="36" height="36"/>
                      </bpmndi:BPMNShape>
                    </bpmndi:BPMNPlane>
                  </bpmndi:BPMNDiagram>
                </bpmn:definitions>`;
        try {
            await this.bpmnModeler.importXML(xml);
            console.log("New diagram loaded.");
        } catch (err) {
            console.error("Diagram import error:", err);
        }
    }

    async onSaveDiagram() {
        if (!this.bpmnModeler) return;

        try {
            const { svg } = await this.bpmnModeler.saveSVG();
            const { xml } = await this.bpmnModeler.saveXML({ format: true });

            const svgBlob = new Blob([svg], { type: "image/svg+xml" });
            const svgUrl = URL.createObjectURL(svgBlob);
            const img = new Image();
            img.width = 70;
            img.height = 70;

            img.onload = async () => {
                const canvas = document.createElement("canvas");
                canvas.width = 70;
                canvas.height = 70;
                const ctx = canvas.getContext("2d");
                ctx.clearRect(0, 0, 70, 70);
                ctx.drawImage(img, 0, 0, 70, 70);

                const base64Png = canvas.toDataURL("image/png").split(",")[1];
                const base64Svg = btoa(unescape(encodeURIComponent(svg)));
                const base64Xml = btoa(unescape(encodeURIComponent(xml)));

                const taskId = this.props.action.context?.task_id;

                try {
                    await this.rpc("/web/dataset/call_kw", {
                        model: "project.task",
                        method: "save_file",
                        args: [],
                        kwargs: {
                            task_id: taskId,
                            content: base64Xml,
                            image_1920: base64Png,
                            image_svg: base64Svg,
                        },
                    });

                    this.notification.add("Diagram saved successfully!", { type: "success" });
                } catch (error) {
                    console.error("RPC Error:", error);
                    this.notification.add("Failed to save diagram.", { type: "danger" });
                }

                URL.revokeObjectURL(svgUrl);
            };

            img.onerror = (e) => {
                console.error("Image load error:", e);
                this.notification.add("Failed to convert SVG to PNG.", { type: "danger" });
            };

            img.src = svgUrl;
        } catch (err) {
            console.error("Save error:", err);
            this.notification.add("Unexpected error during save.", { type: "danger" });
        }
    }

    removeExtensionOrDefault(filename, defaultName = "ITeSolution_Dg_file.svg") {

        const extension = ".svg"
        if (!filename || typeof filename !== "string" || !filename.trim()) {
            return defaultName;
        }
        const index = filename.lastIndexOf('.');
        if (index > 0) {
            let t_file_name = filename.substring(0, index)
            t_file_name += extension
            return t_file_name;
        }
        return filename;
    }
    async onExportSVG() {
        if (!this.bpmnModeler) return;
        try {
            const fileName = this.removeExtensionOrDefault(this.fileName)
            const { svg } = await this.bpmnModeler.saveSVG();
            const blob = new Blob([svg], { type: "image/svg+xml" });
            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");
            link.href = url;
            link.download = fileName;
            link.click();
            URL.revokeObjectURL(url);
        } catch (err) {
            console.error("Export SVG error:", err);
        }
    }

    onCancelDiagram() {
        window.history.back();
    }

    onClickGoBack() {
        window.history.back();
    }
    onUndo() {
        const commandStack = this.bpmnModeler.get("commandStack");
        if (commandStack.canUndo()) {
            commandStack.undo();
            this.notification.add("Undo performed", { type: "info" });
        } else {
            this.notification.add("Nothing to undo", { type: "warning" });
        }
    }

    onRedo() {
        const commandStack = this.bpmnModeler.get("commandStack");
        if (commandStack.canRedo()) {
            commandStack.redo();
            this.notification.add("Redo performed", { type: "info" });
        } else {
            this.notification.add("Nothing to redo", { type: "warning" });
        }
    }
}

BpmnDiagram.template = "itesolution_editor.BpmnDiagram";
registry.category("actions").add("bpmn_diagram_tags", BpmnDiagram);
