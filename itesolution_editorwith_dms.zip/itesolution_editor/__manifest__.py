{
    'name': 'ITeSolution BPMN Diagram Editor',
    'version': '18.0.1.0.0',
    'sequence': -100,
    'summary': 'ITeSolution Diagram Editor Integration',
    'author': 'ITeSolution Team',
    'company': 'ITeSolution Software Services',
    'maintainer': 'ITeSolution Software Services',
    'website': "https://www.itesolution.co.in",
    'category': 'Extra Tools',
    'price': "100.0",
    "curency": "USD",
    'depends': ['base', 'web', 'project'],
    'data': [
        'security/account_security.xml',
        'security/ir.model.access.csv',
        'views/itesolution_editor_view.xml',
        'views/project_task_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            # BPMN JS and CSS
            'itesolution_editor/static/src/lib/bpmn/js/bpmn-modeler.development.js',
            'itesolution_editor/static/src/lib/bpmn/js/bpmn-js-properties-panel.umd.js',
            'itesolution_editor/static/src/lib/bpmn/css/diagram-js.css',
            'itesolution_editor/static/src/lib/bpmn/css/bpmn.css',
            # Dashboard JS and CSS
            'itesolution_editor/static/src/xml/dashboard.xml',
            'itesolution_editor/static/src/js/dashboard.js',
        ],
    },
    'images': ['static/description/banner.png'],
    # 'images': ['static/description/banner.gif'],
    # 'license': 'LGPL-3',
    'license': 'OPL-1',
    'installable': True,
    'application': True,
}
