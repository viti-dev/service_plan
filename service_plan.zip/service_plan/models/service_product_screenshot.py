from odoo import models, fields, api
import base64,re
import requests
from bs4 import BeautifulSoup

import logging

_logger = logging.getLogger(__name__)



class ServiceProductScreenshot(models.Model):
    _name = 'service.product.screenshot'
    _description = 'Service Product Screenshot'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Description")
    image = fields.Binary(string="Screenshot", attachment=True)
    image_html = fields.Html(string="Html Screenshot", attachment=True)

    maintenance_service_prod_id = fields.Many2one('service.product', ondelete="cascade")
    sc_calc_service_product_id = fields.Many2one('service.product', ondelete="cascade")
    wams_price_list_id = fields.Many2one('service.product', ondelete="cascade")
    unique_work_cards_id = fields.Many2one('service.product', ondelete="cascade")
    spns_and_sections_id = fields.Many2one('service.product', ondelete="cascade")
    o_and_mm_id = fields.Many2one('service.product', ondelete="cascade")
    frequency_expressions_id = fields.Many2one('service.product', ondelete="cascade")

    @api.onchange('image_html')
    def _onchange_image_html(self):
        if self.image_html:
            soup = BeautifulSoup(self.image_html, 'html.parser')
            img_tag = soup.find('img')
            if img_tag:
                src = img_tag.get('src', '')
                try:
                    if src.startswith('data:image'):
                        base64_data = src.split(',')[ 1 ]
                        self.image = base64.b64decode(base64_data)
                    elif src.startswith('/web/image'):
                        base_url = self.env[ 'ir.config_parameter' ].sudo().get_param('web.base.url')
                        full_url = base_url + src
                        response = requests.get(full_url)
                        if response.status_code == 200:
                            self.image = base64.b64encode(response.content)
                        else:
                            self.image = False
                    else:
                        self.image = False
                except Exception as e:
                    self.image = False