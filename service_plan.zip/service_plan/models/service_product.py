import logging

from odoo import api, fields, models, tools, _

_logger = logging.getLogger(__name__)


class WorkCardSparePart(models.Model):
    _name = "work.card_spare_part"
    _description = "Spare Part on Work Card"

    work_card_id = fields.Many2one("work.card", string="Work Card", ondelete="cascade")
    part_number = fields.Char(string="Part Number")
    description = fields.Char()
    part_type = fields.Selection([
        ('required', 'Required'),
        ('insp_dep', 'Inspection Dependent'),
        ('new', 'Newly Added'),
    ], string="Type")
    group = fields.Char(string="Spare Part Group")
    qty = fields.Char(string="Qty")
    multiplier = fields.Char(string="Multiplier")


class WorkCard(models.Model):
    _name = "work.card"
    _description = "Work Card"

    name = fields.Char(string="Work Card Description")
    code = fields.Char(string="WCA Code")
    main_group = fields.Char()
    sub_group = fields.Char()
    service_product_id = fields.Many2one("service.product", string="Service Product")
    spare_part_ids = fields.One2many("work.card_spare_part", "work_card_id", string="Spare Parts")
    state = fields.Selection([
        ('active', 'active'),
        ('closed', 'Closed') ], string='State',
        copy=False, default='active', readonly=False)

    @api.model
    def toggle_state(self):
        for record in self:
            record.state = 'closed' if record.state == 'active' else 'active'

class TCData(models.Model):
    _name = "tc.data"
    _description = "Task Code Data"
    _rec_name = "task"

    task = fields.Char(string="Task Description", required=True)
    tc_code = fields.Char(string="TC Code", required=True)
    decision_node = fields.Text(string="Decision node", required=True)
    type_of_work_card = fields.Selection([
        ('Labor', 'Labor'),
        ('Spares and labor', 'Spares and labor'),
    ], string="Type of work card")

    notes = fields.Text(string="Notes")

    maintenance_delivery_id = fields.Many2one('maintenance.delivery_option', string="Maintenance", ondelete="cascade")
    activity = fields.Char("Activity", related='maintenance_delivery_id.activity')
    ws_code = fields.Char("WAMS service product", related='maintenance_delivery_id.ws_code')
    state = fields.Selection([
        ('active', 'active'),
        ('closed', 'Closed') ], string='State',
        copy=False, default='active', readonly=False)

OPTION_TYPE = {'standard': 'Standard Maintenance',
               'customer': 'Customer-Owned Swing Set Maintenance',
               'swap': 'Swap Service Based Maintenance'}
LOCATION = {'site':'At Site','workshop':'Workshop'}


class MaintenanceDeliveryOption(models.Model):
    _name = "maintenance.delivery_option"
    _description = "Maintenance Delivery Option"


    schedule_id = fields.Many2one('service.configurator', string="Schedule", ondelete="cascade")
    activity = fields.Char("activity", related='schedule_id.activity')
    option_type = fields.Selection([
        ('standard', 'Standard Maintenance'),
        ('customer', 'Customer-Owned Swing Set Maintenance'),
        ('swap', 'Swap Service Based Maintenance'),
    ], string="Option Type", required=True)
    sub_activity = fields.Selection([
        ('Maintenance in workshop', 'Maintenance in workshop'),
        ('Maintenance at site', 'Maintenance at site'),
    ], string="Sub Activity")
    location = fields.Selection([
        ('site', 'At Site'),
        ('workshop', 'Workshop'),
    ], string="Location")
    ws_code = fields.Char(string="WS Code")
    task = fields.Char(string="Task")
    notes = fields.Text(string="Notes")

    tc_data_ids = fields.One2many('tc.data', 'maintenance_delivery_id', string="Delivery Options")
    display_name = fields.Char(string='Display Name', compute='_compute_display_name', store=True)

    @api.depends('option_type', 'location', 'task')
    def _compute_display_name(self):
        option_selection = dict(self.fields_get(allfields=[ 'option_type' ])[ 'option_type' ][ 'selection' ])
        location_selection = dict(self.fields_get(allfields=[ 'location' ])[ 'location' ][ 'selection' ])

        for record in self:
            option_label = option_selection.get(record.option_type, '')
            location_label = location_selection.get(record.location, '')
            record.display_name = f"{option_label} - {record.task or ''} - {location_label}"


class ServiceConfigurator(models.Model):
    _name = "service.configurator"
    _description = "Service Configurator"
    _rec_name = 'activity'

    interval = fields.Char('Interval')
    activity = fields.Char('Activity')
    delivery_option_ids = fields.One2many('maintenance.delivery_option', 'schedule_id', string="Delivery Options")
    configurator_service_prod_id = fields.Many2one('service.product', ondelete="cascade")
    state = fields.Selection([
            ('active', 'active'),
            ('closed', 'Closed') ], string='State',
            copy=False, default='active', readonly=False)

    delivery_option_table_html = fields.Html(compute='_compute_delivery_option_table', store=False)


    @api.depends('delivery_option_ids')
    def _compute_delivery_option_table(self):
        table_data = """<table class="table table-bordered table-sm mt-2">
                                                                <thead class="table-light">
                                                                    <tr>
                                                                        <th style="width: 10%;"></th>
                                                                        <th style="width: 50%">Activity</th>
                                                                        <th>WS Code</th>
                                                                        <th>Last Done</th>
                                                                        <th>Notes</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>"""
        table_data_end = """</tbody>
                                                            </table>"""

        for rec in self:
            task_list = {}
            for line in rec.delivery_option_ids:
                line_data = {'task': line.task, 'ws_code': line.ws_code, 'location': line.location}
                if line.option_type in task_list.keys():
                    task_data = task_list.get(line.option_type)

                    if line.sub_activity in ['Maintenance in workshop','Maintenance at site']:
                        sub_task_list = task_data.get('sub_task_list')
                        if sub_task_list.get(line.sub_activity):
                            sub_list = sub_task_list.get(line.sub_activity)
                            sub_list.append(line_data)
                        else:
                            sub_task_list[line.sub_activity] = [line_data]
                    else:
                        task_list_arr = task_data.get('task_list')
                        task_list_arr.append(line_data)
                else:
                    if line.sub_activity in ['Maintenance in workshop','Maintenance at site']:
                        task_list[line.option_type] = {
                            'task_list': [],
                            'sub_task_list': {line.sub_activity:[line_data]}}
                    else:

                        task_list[line.option_type] = {'task_list':[{'task':line.task, 'ws_code':line.ws_code, 'location':line.location}],
                                                       'sub_task_list':{}}
            td_d = table_data
            for task_header in task_list.keys():
                task_header_1 = OPTION_TYPE.get(task_header, '')
                td_d = td_d + f'<tr><td></td><td colspan="4" class="card-header bg-secondary text-white fw-bold py-1" style="color: black !important; background-color: antiquewhite !important;">&#9673;&nbsp;{task_header_1}</td></tr>'
                task_list_dic = task_list.get(task_header)
                for task_d in task_list_dic.get('task_list'):
                    task_t = task_d.get('task','')
                    ws_code = task_d.get('ws_code','') if task_d.get('ws_code','') else ''
                    location = task_d.get('location', '') if task_d.get('location', '') else ''
                    td_d = td_d + f'<tr><td></td><td>&#9746;&nbsp;{task_t}</td><td>{ws_code}</td><td>{location}</td></tr>'

                sub_task_list = task_list_dic.get('sub_task_list')
                for sub_t_key in sub_task_list.keys():
                    td_d = td_d + f'<tr><td></td><td colspan="4" class="card-header bg-secondary text-white fw-bold py-1" style="color: black !important; background-color: antiquewhite !important; padding-left: 20px">&#9673;&nbsp;{sub_t_key}</td></tr>'
                    for task_d in sub_task_list.get(sub_t_key):
                        task_t = task_d.get('task', '')
                        ws_code = task_d.get('ws_code', '') if task_d.get('ws_code', '') else ''
                        location = task_d.get('location', '') if task_d.get('location', '') else ''
                        td_d = td_d + f'<tr><td></td><td style=" padding-left: 30px;">&#9746;&nbsp;{task_t}</td><td>{ws_code}</td><td>{location}</td></tr>'

            td_d += table_data_end
            rec.delivery_option_table_html = td_d




class ServiceComponent(models.Model):
    _name = "service.component"
    _description = "Service Component"
    _rec_name = 'name'
    _order = "priority"

    name = fields.Char('Component Name')
    priority = fields.Integer(string='Priority', default=10, required=True)
    product_reference_id = fields.Many2one('service.product_reference',
                                           string="Product Reference Type", required=True)


class ServiceProductReference(models.Model):
    _name = "service.product_reference"
    _description = "Service Product Reference"
    _rec_name = 'name'

    name = fields.Char('Product Reference', required=True)


class ServiceProduct(models.Model):
    _name = "service.product"
    _description = "Service Product"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Name')
    group = fields.Char('Group')
    sub_group = fields.Char('Sub-group (L1)')
    product_reference_id = fields.Many2one('service.product_reference', required=True,
                                           string="Product Reference Type")

    service_component_id = fields.Many2one('service.component', string="Service Component",
                                           ondelete="cascade", required=True)

    description = fields.Html('Description')
    maintenance_checklist = fields.Html()

    maintenance_screenshot_ids = fields.One2many('service.product.screenshot',
                                                 'maintenance_service_prod_id', string="Screenshots")
    sc_calc_screenshot_ids = fields.One2many('service.product.screenshot',
                                             'sc_calc_service_product_id', string="Screenshots")

    wams_price_screenshot_ids = fields.One2many('service.product.screenshot',
                                                'wams_price_list_id', string="Screenshots")
    unique_work_card_screenshot_ids = fields.One2many('service.product.screenshot',
                                                      'unique_work_cards_id', string="Screenshots")
    work_card_ids = fields.One2many("work.card", "service_product_id", string="Work Cards")

    spns_and_sections_screenshot_ids = fields.One2many('service.product.screenshot',
                                                       'spns_and_sections_id', string="Screenshots")
    o_and_mm_screenshot_ids = fields.One2many('service.product.screenshot',
                                              'o_and_mm_id', string="Screenshots")
    frequency_expressions_screenshot_ids = fields.One2many('service.product.screenshot',
                                                           'frequency_expressions_id', string="Screenshots")

    service_configurator_ids = fields.One2many('service.configurator',
                                               'configurator_service_prod_id', string="Screenshots")

    tc_data_ids = fields.One2many(
        comodel_name='tc.data',
        inverse_name='maintenance_delivery_id',
        string="TC Data (Auto-linked)",
        compute='_compute_tc_data_ids',
        store=False
    )

    author_id = fields.Many2one(
        "res.partner",
        "Assigned To",
        required=True,
        default=lambda self: self.env.user.partner_id,
    )

    step1_state = fields.Selection([
        ('open', 'Open'), ('active', 'Active'),
        ('closed', 'Closed') ], string='State',
        copy=False, default='open', readonly=False)
    maintenance_screenshot_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='Maintenance State',
        copy=False, default='open', readonly=False)
    sc_calc_screenshot_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='Sc Calculation State',
        copy=False, default='open', readonly=False)
    wams_price_screenshot_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='Workshops WAMS State',
        copy=False, default='open', readonly=False)
    unique_work_card_screenshot_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='Unique work cards State',
        copy=False, default='open', readonly=False)
    work_card_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='Work Cards State',
        copy=False, default='open', readonly=False)
    spns_and_sections_screenshot_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='SPNs and sections State',
        copy=False, default='open', readonly=False)
    o_and_mm_screenshot_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='O&MM State',
        copy=False, default='open', readonly=False)
    frequency_expressions_screenshot_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='Frequency Expressions State',
        copy=False, default='open', readonly=False)
    service_configurator_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='Configurator view State',
        copy=False, default='open', readonly=False)
    tc_data_state = fields.Selection([
        ('open', 'Open'),('active', 'Active'),
        ('closed', 'Closed')], string='TC Data State',
        copy=False, default='open', readonly=False)

    target_date = fields.Datetime("Target Date", default= fields.Date.today())

    progress_html = fields.Html(
        string="Progress by all Work items",
        sanitize=False,
        readonly=True,
        store=True,
        compute="_compute_progress_and_state"
    )

    state_dot_html = fields.Html(
        string="State",
        sanitize=False,
        readonly=True,
        store=True,
        compute="_compute_progress_and_state"
    )

    progress_bar = fields.Char(
        string="Progress Bar",
        readonly=True,
        store=True,
        compute="_compute_progress_and_state"
    )

    progress_value = fields.Float(
        string="Progress %",
        readonly=True,
        compute="_compute_progress_and_state",
        store=True
    )
    section_progres = fields.Integer(default=100)

    STATE_FIELDS = [
        'step1_state',
        'maintenance_screenshot_state',
        'sc_calc_screenshot_state',
        'wams_price_screenshot_state',
        'unique_work_card_screenshot_state',
        # 'work_card_state',  # Optional, you’ve commented it out
        'spns_and_sections_screenshot_state',
        'o_and_mm_screenshot_state',
        'frequency_expressions_screenshot_state',
        'service_configurator_state',
        'tc_data_state',
    ]

    @api.depends(*STATE_FIELDS)
    def _compute_progress_and_state(self):
        for record in self:
            states = [ getattr(record, field) for field in self.STATE_FIELDS ]
            total = len(states)
            closed = sum(1 for s in states if s == 'closed')
            percent = int((closed / total) * 100) if total else 0
            record.progress_value = percent
            record.progress_bar = f"{percent}%"
            if percent == 100:
                color = 'green'
            elif percent == 0:
                color = 'gray'
            else:
                color = 'blue'
            record.progress_html = f'''
                    <div style="display: flex; align-items: center; gap: 4px;">
                        <div style="width: 140px; background-color: #eee; border-radius: 3px; height: 15px; position: relative;">
                            <div style="width: {percent}%; background-color: {color}; height: 100%; border-radius: 3px;"></div>
                        </div>
                        <span style="font-size: 10px; color: #000;">{percent:.0f}%</span>
                    </div>
                '''
            if all(s == 'closed' for s in states):
                dot_color = 'green'
                label = 'Closed'
            elif any(s in ('active', 'closed') for s in states) and not all(s == 'closed' for s in states):
                dot_color = 'blue'
                label = 'Active'
            else:
                dot_color = 'gray'
                label = 'Open'

            record.state_dot_html = f'''
                    <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background-color:{dot_color};margin-right:5px;"></span>
                    {label}
                '''

    @api.depends('service_configurator_ids.delivery_option_ids.tc_data_ids')
    def _compute_tc_data_ids(self):
        for record in self:
            tc_data = self.env['tc.data'].search([
                ('maintenance_delivery_id.schedule_id.configurator_service_prod_id', '=', record.id)
            ])
            record.tc_data_ids = tc_data

    def action_open_tc_data_wizard(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Add TC Data',
            'res_model': 'tc.data',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                # Optional: prefill a delivery option if available
                'default_maintenance_delivery_id': self.service_configurator_ids
                                                   .mapped('delivery_option_ids')[:1].id or False
            }
        }

    def write(self, vals):
        res = super().write(vals)
        for record in self:
            new_progress = vals.get('progress_value', record.progress_value)
            if new_progress == 100 and record:
                already_exists = self.env[ 'project.approval.matrix' ].search_count([
                    ('project_id', '=', record.id) ])
                if not already_exists:
                    self.env[ 'project.approval.matrix' ].create({'project_id': record.id})
        return res

