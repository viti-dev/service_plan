from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class ServiceProductApprovalTemplate(models.Model):
    _name = 'service.product.approval.template'
    _description = 'Service Product Approval Template'

    name = fields.Char("Approval Type", required=True)
    sequence = fields.Integer(
        default=lambda self: self.env[ 'service.product.approval.template' ].search([ ], order='sequence desc',
                                                                                    limit=1).sequence + 1 if self.env[
            'service.product.approval.template' ].search([ ], order='sequence desc', limit=1) else 1)
    approver_id = fields.Many2one('res.users', string="Approvers")


class ProjectApprovalMatrix(models.Model):
    _name = 'project.approval.matrix'
    _description = 'Project Approval Matrix'
    _inherit = [ 'mail.thread', 'mail.activity.mixin' ]
    _rec_name = 'project_id'

    project_id = fields.Many2one('service.product', string="Project", required=True)
    approver_line_ids = fields.One2many('project.approval.line', 'matrix_id', string="Approvers")

    delivery_status = fields.Selection([
        ('not_started', 'Not Started'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ],default='not_started', string="Delivery Approval", tracking=True, compute="_compute_statuses", store=True)

    sales_status = fields.Selection([
        ('not_started', 'Not Started'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], default='not_started', string="Sales Approval", tracking=True, compute="_compute_statuses", store=True)

    technical_status = fields.Selection([
        ('not_started', 'Not Started'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], default='not_started', string="Technical Approval",tracking=True, compute="_compute_statuses", store=True)

    final_status = fields.Selection([
        ('not_started', 'Not Started'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ],default='not_started', string="Final Approval", tracking=True, compute="_compute_statuses", store=True)

    @api.depends('approver_line_ids.status', 'approver_line_ids.approval_type')
    def _compute_statuses(self):
        for record in self:
            record.delivery_status = record._get_status_for_type('Delivery Approval')
            record.sales_status = record._get_status_for_type('Sales Approval')
            record.technical_status = record._get_status_for_type('Technical Approval')
            record.final_status = record._get_status_for_type('Final Approval')

    def _get_status_for_type(self, type_name):
        line = self.approver_line_ids.filtered(lambda l: l.approval_type.name == type_name)
        return line[ 0 ].status if line else 'not_started'

    @api.model
    def create(self, vals):
        record = super().create(vals)
        templates = self.env[ 'service.product.approval.template' ].search([ ])
        lines = [ ]
        for template in templates:
            if template.approver_id:  # check it's set
                lines.append((0, 0, {
                    'approval_type': template.id,
                    'user_id': template.approver_id.id,
                    'status': 'not_started',
                }))
        record.approver_line_ids = lines
        return record

    def get_approver_lines(self):
        return "self.approver_line_ids.filtered(lambda l: l.status != 'not_started')"


class ProjectApprovalLine(models.Model):
    _name = 'project.approval.line'
    _description = 'Project Approval Line'

    matrix_id = fields.Many2one('project.approval.matrix', string="Approval Matrix", ondelete='cascade')
    approval_type = fields.Many2one('service.product.approval.template', string="Approval Type", required=True, readonly=True)
    user_id = fields.Many2one(related='approval_type.approver_id', string="Approver", store=True)
    status = fields.Selection([
        ('not_started', 'Not Started'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string="Status", default='not_started', tracking=True,)

    def write(self, vals):
        if 'status' in vals:
            for record in self:
                if record.user_id and record.user_id.id != self.env.user.id:
                    raise UserError(_("You can only change the status if you are the assigned approver."))
        return super(ProjectApprovalLine, self).write(vals)
