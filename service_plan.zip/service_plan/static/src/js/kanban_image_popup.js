/** @odoo-module **/
import { KanbanRecord } from "@web/views/kanban/kanban_record";
import { Dialog } from "@web/core/dialog/dialog";
import { patch } from "@web/core/utils/patch";

patch(KanbanRecord.prototype, {
    setup() {
        super.setup();
        this.onImageClick = this.onImageClick.bind(this);
    },

    _getEventHandlers() {
        const handlers = super._getEventHandlers?.() || {};
        return {
            ...handlers,
            'click .oe_kanban_image': this.onImageClick,
        };
    },

    onImageClick(ev) {
        ev.preventDefault();
        const recordId = this.props.record.resId;
        const imageUrl = `/web/image/service.product.screenshot/${recordId}/image`;

        new Dialog(this, {
            title: "Screenshot",
            className: 'screenshot-fullscreen-dialog',
            body: {
                __html: `
                    <div style="position: relative; width: 100%; height: 100%; text-align: center; background: #000;">
                        <a href="${imageUrl}" download style="position: absolute; top: 20px; right: 20px; z-index: 1000; color: white; font-size: 24px;" title="Download Image">
                            <i class="fa fa-download"></i>
                        </a>
                        <img src="${imageUrl}" style="max-width:100%; max-height:100%; margin-top: 40px;" />
                    </div>
                `,
            },
        }).open();
    },
});


//odoo.define('service_plan.kanban_image_popup', function (require) {
//    "use strict";
//
//    const KanbanRecord = require('web.KanbanRecord');
//    const Dialog = require('web.Dialog');
//
//    KanbanRecord.include({
//        events: Object.assign({}, KanbanRecord.prototype.events, {
//            'click .oe_kanban_image': '_onImageClick',
//        }),
//
//        _onImageClick: function (ev) {
//            ev.preventDefault();
//            const recordId = this.record.id.raw_value;
//            const imageUrl = `/web/image/service.product.screenshot/${recordId}/image`;
//
//            new Dialog(this, {
//                title: "Screenshot", // Hide title for a cleaner fullscreen
//                dialogClass: 'screenshot-fullscreen-dialog',
//                $content: $(`
//                    <div style="position: relative; width: 100%; height: 100%; text-align: center; background: #000;">
//                        <a href="${imageUrl}" download style="position: absolute; top: 20px; right: 20px; z-index: 1000; color: white; font-size: 24px;" title="Download Image">
//                            <i class="fa fa-download"></i>
//                        </a>
//                        <img src="${imageUrl}" style="max-width:100%; max-height:100%; margin-top: 40px;" />
//                    </div>
//                `),
//            }).open();
//
//
//        },
//    });
//});
