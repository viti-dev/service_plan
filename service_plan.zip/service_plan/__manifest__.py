{
    'name': 'Service Plan WOW CYEIMS',
    'version': '18.0.1.0',
    'category': 'Cyient',
    'sequence': -105,
    'summary': 'Service Plan WOW',
    'description': "",
    'depends': ['base', 'mail', 'web'],
    'data': [
        # 'security/service_plan_security.xml',
        'security/ir.model.access.csv',
        'views/service_product_views.xml',
        'views/service_product_approval_views.xml',
        'views/service_plan_menu.xml',
        'data/approval_template_demo.xml'
    ],
    'assets': {
    'web.assets_backend': [
        'service_plan/static/src/js/kanban_image_popup.js',
        'service_plan/static/src/css/screenshot_popup.css',
    ],
    },

    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}
